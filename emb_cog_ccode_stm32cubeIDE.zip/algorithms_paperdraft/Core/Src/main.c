/* USER CODE BEGIN Header */
/**
    ******************************************************************************
    * @file                     : main.c
    * @brief                    : Main program body
    ******************************************************************************
    * @attention
    *
    * Copyright (c) 2023 STMicroelectronics.
    * All rights reserved.
    *
    * This software is licensed under terms that can be found in the LICENSE file
    * in the root directory of this software component.
    * If no LICENSE file comes with this software, it is provided AS-IS.
    *
    ******************************************************************************
    */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "string.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "dsp/support_functions.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ARM_MATH_CM7
#define BSIZE (256)
#define NOISE (0)
#define RED_RESOLUTION (0)
#define BR_BTW_MEAS (0x0A)

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
#if defined ( __ICCARM__ ) /*!< IAR Compiler */
#pragma location=0x30000000
ETH_DMADescTypeDef  DMARxDscrTab[ETH_RX_DESC_CNT]; /* Ethernet Rx DMA Descriptors */
#pragma location=0x30000200
ETH_DMADescTypeDef  DMATxDscrTab[ETH_TX_DESC_CNT]; /* Ethernet Tx DMA Descriptors */

#elif defined ( __CC_ARM )  /* MDK ARM Compiler */

__attribute__((at(0x30000000))) ETH_DMADescTypeDef  DMARxDscrTab[ETH_RX_DESC_CNT]; /* Ethernet Rx DMA Descriptors */
__attribute__((at(0x30000200))) ETH_DMADescTypeDef  DMATxDscrTab[ETH_TX_DESC_CNT]; /* Ethernet Tx DMA Descriptors */

#elif defined ( __GNUC__ ) /* GNU Compiler */
ETH_DMADescTypeDef DMARxDscrTab[ETH_RX_DESC_CNT] __attribute__((section(".RxDecripSection"))); /* Ethernet Rx DMA Descriptors */
ETH_DMADescTypeDef DMATxDscrTab[ETH_TX_DESC_CNT] __attribute__((section(".TxDecripSection")));   /* Ethernet Tx DMA Descriptors */

#endif

ETH_TxPacketConfig TxConfig;

ETH_HandleTypeDef heth;

RNG_HandleTypeDef hrng;

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
char txbuf1[22];
char txbuf2[22];
char txbuf3[22];
char txbuf4[22];

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ETH_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_USB_OTG_HS_USB_Init(void);
static void MX_RNG_Init(void);
/* USER CODE BEGIN PFP */
void arm_mult_q31(const q31_t * pSrcA, const q31_t * pSrcB, q31_t * pDst, uint32_t blockSize);
//__attribute__( ( long_call, section(".data") ) )
float32_t calcCoG(uint16_t* refPw,uint32_t* tuneVolt,uint32_t th,uint32_t thlw,uint32_t maxADCVal);


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* Enable I-Cache---------------------------------------------------------*/
  SCB_EnableICache();

  /* Enable D-Cache---------------------------------------------------------*/
  SCB_EnableDCache();

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ETH_Init();
  MX_USART3_UART_Init();
  MX_USB_OTG_HS_USB_Init();
  MX_RNG_Init();
  /* USER CODE BEGIN 2 */
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    //General Variables
    // CoG is only calculated for the Gauss reflection, the left side is detected with lower than calcThresh,
    // the right side  with higher than calcThres+hystCalc
    const uint16_t calcThresh = 16370; //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    const uint32_t hystCalc = 5;       //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    const uint32_t calcThreshLwr=calcThresh+hystCalc;

    uint32_t MAX_ADCVAL;
    MAX_ADCVAL = 16383;
    float32_t MAXADCVALFLOAT;
    MAXADCVALFLOAT= (float32_t) MAX_ADCVAL;
    float32_t MAX_Q31_TO_FLOAT_SCALE;
    MAX_Q31_TO_FLOAT_SCALE=2147483648.0f;
    float32_t MAX_REFL_VAL;
    MAX_REFL_VAL=40000.0f;//8300.0f;

    //Tuning Voltages as they are sent to the DAC
    volatile float32_t  f32tuneVolt[BSIZE] ={ 0.000000f,0.084000f,0.168000f,0.252000f,0.336000f,0.420000f,0.504000f,0.588000f,0.672000f,0.756000f,0.840000f,0.924000f,1.008000f,1.092000f,1.176000f,1.260000f,1.344000f,1.428000f,1.512000f,1.596000f,1.680000f,1.764000f,1.848000f,1.932000f,2.016000f,2.100000f,2.184000f,2.268000f,2.352000f,2.436000f,2.520000f,2.604000f,2.688000f,2.772000f,2.856000f,2.940000f,3.024000f,3.108000f,3.192000f,3.276000f,3.360000f,3.444000f,3.528000f,3.612000f,3.696000f,3.780000f,3.864000f,3.948000f,4.032000f,4.116000f,4.200000f,4.284000f,4.368000f,4.452000f,4.536000f,4.620000f,4.704000f,4.788000f,4.872000f,4.956000f,5.040000f,5.124000f,5.208000f,5.292000f,5.376000f,5.460000f,5.544000f,5.628000f,5.712000f,5.796000f,5.880000f,5.964000f,6.048000f,6.132000f,6.216000f,6.300000f,6.384000f,6.468000f,6.552000f,6.636000f,6.720000f,6.804000f,6.888000f,6.972000f,7.056000f,7.140000f,7.224000f,7.308000f,7.392000f,7.476000f,7.560000f,7.644000f,7.728000f,7.812000f,7.896000f,7.980000f,8.064000f,8.148000f,8.232000f,8.316000f,8.400000f,8.484000f,8.568000f,8.652000f,8.736000f,8.820000f,8.904000f,8.988000f,9.072000f,9.156000f,9.240000f,9.324000f,9.408000f,9.492000f,9.576000f,9.660000f,9.744000f,9.828000f,9.912000f,9.996000f,10.080000f,10.164000f,10.248000f,10.332000f,10.416000f,10.500000f,10.584000f,10.668000f,10.752000f,10.836000f,10.920000f,11.004000f,11.088000f,11.172000f,11.256000f,11.340000f,11.424000f,11.508000f,11.592000f,11.676000f,11.760000f,11.844000f,11.928000f,12.012000f,12.096000f,12.180000f,12.264000f,12.348000f,12.432000f,12.516000f,12.600000f,12.684000f,12.768000f,12.852000f,12.936000f,13.020000f,13.104000f,13.188000f,13.272000f,13.356000f,13.440000f,13.524000f,13.608000f,13.692000f,13.776000f,13.860000f,13.944000f,14.028000f,14.112000f,14.196000f,14.280000f,14.364000f,14.448000f,14.532000f,14.616000f,14.700000f,14.784000f,14.868000f,14.952000f,15.036000f,15.120000f,15.204000f,15.288000f,15.372000f,15.456000f,15.540000f,15.624000f,15.708000f,15.792000f,15.876000f,15.960000f,16.044000f,16.128000f,16.212000f,16.296000f,16.380000f,16.464000f,16.548000f,16.632000f,16.716000f,16.800000f,16.884000f,16.968000f,17.052000f,17.136000f,17.220000f,17.304000f,17.388000f,17.472000f,17.556000f,17.640000f,17.724000f,17.808000f,17.892000f,17.976000f,18.060000f,18.144000f,18.228000f,18.312000f,18.396000f,18.480000f,18.564000f,18.648000f,18.732000f,18.816000f,18.900000f,18.984000f,19.068000f,19.152000f,19.236000f,19.320000f,19.404000f,19.488000f,19.572000f,19.656000f,19.740000f,19.824000f,19.908000f,19.992000f,20.076000f,20.160000f,20.244000f,20.328000f,20.412000f,20.496000f,20.580000f,20.664000f,20.748000f,20.832000f,20.916000f,21.000000f,21.084000f,21.168000f,
                                             21.252000f,21.336000f,21.420000f};
    //Tuning Voltages multiplied by 100 and rounded
    volatile uint32_t i32tuneVolt[BSIZE] ={0,8,17,25,34,42,50,59,67,76,84,92,101,109,118,126,134,143,151,160,168,176,185,193,202,210,218,227,235,244,252,260,269,277,286,294,302,311,319,328,336,344,353,361,370,378,386,395,403,412,420,428,437,445,454,462,470,479,487,496,504,512,521,529,538,546,554,563,571,580,588,596,605,613,622,630,638,647,655,664,672,680,689,697,706,714,722,731,739,748,756,764,773,781,790,798,806,815,823,832,840,848,857,865,874,882,890,899,907,916,924,932,941,949,958,966,974,983,991,1000,1008,1016,1025,1033,1042,1050,1058,1067,1075,1084,1092,1100,1109,1117,1126,1134,1142,1151,1159,1168,1176,1184,1193,1201,1210,1218,1226,1235,1243,1252,1260,1268,1277,1285,1294,1302,1310,1319,1327,1336,1344,1352,1361,1369,1378,1386,1394,1403,1411,1420,1428,1436,1445,1453,1462,1470,1478,1487,1495,1504,1512,1520,1529,1537,1546,1554,1562,1571,1579,1588,1596,1604,1613,1621,1630,1638,1646,1655,1663,1672,1680,1688,1697,1705,1714,1722,1730,1739,1747,1756,1764,1772,1781,1789,1798,1806,1814,1823,1831,1840,1848,1856,1865,1873,1882,1890,1898,1907,1915,1924,1932,1940,1949,1957,1966,1974,1982,1991,1999,2008,2016,2024,2033,2041,2050,2058,2066,2075,2083,2092,2100,2108,2117,
                                           2125,2134,2142};
    //Tuning Voltages in q31 format [-1...1]
    volatile float32_t q31f32tuneVolt[BSIZE] ={0.000000f,0.003907f,0.007814f,0.011721f,0.015628f,0.019535f,0.023442f,0.027349f,0.031256f,0.035163f,0.039070f,0.042977f,0.046884f,0.050791f,0.054698f,0.058605f,0.062512f,0.066419f,0.070326f,0.074233f,0.078140f,0.082047f,0.085953f,0.089860f,0.093767f,0.097674f,0.101581f,0.105488f,0.109395f,0.113302f,0.117209f,0.121116f,0.125023f,0.128930f,0.132837f,0.136744f,0.140651f,0.144558f,0.148465f,0.152372f,0.156279f,0.160186f,0.164093f,0.168000f,0.171907f,0.175814f,0.179721f,0.183628f,0.187535f,0.191442f,0.195349f,0.199256f,0.203163f,0.207070f,0.210977f,0.214884f,0.218791f,0.222698f,0.226605f,0.230512f,0.234419f,0.238326f,0.242233f,0.246140f,0.250047f,0.253953f,0.257860f,0.261767f,0.265674f,0.269581f,0.273488f,0.277395f,0.281302f,0.285209f,0.289116f,0.293023f,0.296930f,0.300837f,0.304744f,0.308651f,0.312558f,0.316465f,0.320372f,0.324279f,0.328186f,0.332093f,0.336000f,0.339907f,0.343814f,0.347721f,0.351628f,0.355535f,0.359442f,0.363349f,0.367256f,0.371163f,0.375070f,0.378977f,0.382884f,0.386791f,0.390698f,0.394605f,0.398512f,0.402419f,0.406326f,0.410233f,0.414140f,0.418047f,0.421953f,0.425860f,0.429767f,0.433674f,0.437581f,0.441488f,0.445395f,0.449302f,0.453209f,0.457116f,0.461023f,0.464930f,0.468837f,0.472744f,0.476651f,0.480558f,0.484465f,0.488372f,0.492279f,0.496186f,0.500093f,0.504000f,0.507907f,0.511814f,0.515721f,0.519628f,0.523535f,0.527442f,0.531349f,0.535256f,0.539163f,0.543070f,0.546977f,0.550884f,0.554791f,0.558698f,0.562605f,0.566512f,0.570419f,0.574326f,0.578233f,0.582140f,0.586047f,0.589953f,0.593860f,0.597767f,0.601674f,0.605581f,0.609488f,0.613395f,0.617302f,0.621209f,0.625116f,0.629023f,0.632930f,0.636837f,0.640744f,0.644651f,0.648558f,0.652465f,0.656372f,0.660279f,0.664186f,0.668093f,0.672000f,0.675907f,0.679814f,0.683721f,0.687628f,0.691535f,0.695442f,0.699349f,0.703256f,0.707163f,0.711070f,0.714977f,0.718884f,0.722791f,0.726698f,0.730605f,0.734512f,0.738419f,0.742326f,0.746233f,0.750140f,0.754047f,0.757953f,0.761860f,0.765767f,0.769674f,0.773581f,0.777488f,0.781395f,0.785302f,0.789209f,0.793116f,0.797023f,0.800930f,0.804837f,0.808744f,0.812651f,0.816558f,0.820465f,0.824372f,0.828279f,0.832186f,0.836093f,0.840000f,0.843907f,0.847814f,0.851721f,0.855628f,0.859535f,0.863442f,0.867349f,0.871256f,0.875163f,0.879070f,0.882977f,0.886884f,0.890791f,0.894698f,0.898605f,0.902512f,0.906419f,0.910326f,0.914233f,0.918140f,0.922047f,0.925953f,0.929860f,0.933767f,0.937674f,0.941581f,0.945488f,0.949395f,0.953302f,0.957209f,0.961116f,0.965023f,0.968930f,0.972837f,0.976744f,0.980651f,0.984558f,
                                               0.988465f,0.992372f,0.996279f};
    volatile float32_t q31f32tuneVolt_[BSIZE]={0.000000f,0.000391f,0.000781f,0.001172f,0.001563f,0.001953f,0.002344f,0.002735f,0.003126f,0.003516f,0.003907f,0.004298f,0.004688f,0.005079f,0.005470f,0.005860f,0.006251f,0.006642f,0.007033f,0.007423f,0.007814f,0.008205f,0.008595f,0.008986f,0.009377f,0.009767f,0.010158f,0.010549f,0.010940f,0.011330f,0.011721f,0.012112f,0.012502f,0.012893f,0.013284f,0.013674f,0.014065f,0.014456f,0.014847f,0.015237f,0.015628f,0.016019f,0.016409f,0.016800f,0.017191f,0.017581f,0.017972f,0.018363f,0.018753f,0.019144f,0.019535f,0.019926f,0.020316f,0.020707f,0.021098f,0.021488f,0.021879f,0.022270f,0.022660f,0.023051f,0.023442f,0.023833f,0.024223f,0.024614f,0.025005f,0.025395f,0.025786f,0.026177f,0.026567f,0.026958f,0.027349f,0.027740f,0.028130f,0.028521f,0.028912f,0.029302f,0.029693f,0.030084f,0.030474f,0.030865f,0.031256f,0.031647f,0.032037f,0.032428f,0.032819f,0.033209f,0.033600f,0.033991f,0.034381f,0.034772f,0.035163f,0.035553f,0.035944f,0.036335f,0.036726f,0.037116f,0.037507f,0.037898f,0.038288f,0.038679f,0.039070f,0.039460f,0.039851f,0.040242f,0.040633f,0.041023f,0.041414f,0.041805f,0.042195f,0.042586f,0.042977f,0.043367f,0.043758f,0.044149f,0.044540f,0.044930f,0.045321f,0.045712f,0.046102f,0.046493f,0.046884f,0.047274f,0.047665f,0.048056f,0.048447f,0.048837f,0.049228f,0.049619f,0.050009f,0.050400f,0.050791f,0.051181f,0.051572f,0.051963f,0.052353f,0.052744f,0.053135f,0.053526f,0.053916f,0.054307f,0.054698f,0.055088f,0.055479f,0.055870f,0.056260f,0.056651f,0.057042f,0.057433f,0.057823f,0.058214f,0.058605f,0.058995f,0.059386f,0.059777f,0.060167f,0.060558f,0.060949f,0.061340f,0.061730f,0.062121f,0.062512f,0.062902f,0.063293f,0.063684f,0.064074f,0.064465f,0.064856f,0.065247f,0.065637f,0.066028f,0.066419f,0.066809f,0.067200f,0.067591f,0.067981f,0.068372f,0.068763f,0.069153f,0.069544f,0.069935f,0.070326f,0.070716f,0.071107f,0.071498f,0.071888f,0.072279f,0.072670f,0.073060f,0.073451f,0.073842f,0.074233f,0.074623f,0.075014f,0.075405f,0.075795f,0.076186f,0.076577f,0.076967f,0.077358f,0.077749f,0.078140f,0.078530f,0.078921f,0.079312f,0.079702f,0.080093f,0.080484f,0.080874f,0.081265f,0.081656f,0.082047f,0.082437f,0.082828f,0.083219f,0.083609f,0.084000f,0.084391f,0.084781f,0.085172f,0.085563f,0.085953f,0.086344f,0.086735f,0.087126f,0.087516f,0.087907f,0.088298f,0.088688f,0.089079f,0.089470f,0.089860f,0.090251f,0.090642f,0.091033f,0.091423f,0.091814f,0.092205f,0.092595f,0.092986f,0.093377f,0.093767f,0.094158f,0.094549f,0.094940f,0.095330f,0.095721f,0.096112f,0.096502f,0.096893f,0.097284f,0.097674f,0.098065f,0.098456f,
                                               0.098847f,0.099237f,0.099628f};
    //Reflected Power as measured by ADC via TIA and Photodiode
    volatile uint16_t reflPwr[BSIZE]={16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16377,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16380,16366,16339,16295,16267,16122,15753,14685,12696,10410,8724,8189,10432,14016,16059,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383,16383};

    //variables for each data type
    float32_t f32reflPwr;
    float64_t f64reflPwr[BSIZE];
    uint32_t i32reflPwr;
    float32_t f32result;
    float64_t f64result;
    float32_t i32result;
    q31_t q31reflPwr;
    float32_t q31result;
    q31_t q31tuneVolt[BSIZE];
    q31_t q31tuneVolt_[BSIZE];
    float32_t f32accum1, f32accum2;
    float64_t f64accum1, f64accum2;
    uint32_t i32accum1, i32accum2;
    q31_t q31accum1, q31accum2;
    float32_t q31faccum1;
    float32_t q31faccum2;
    uint32_t randomReflPwr[BSIZE];
    uint32_t rand;

    // cycle counter regsiters and variables
    volatile unsigned int *DWT_CYCCNT   = (volatile unsigned int *)0xE0001004; //address of the register
    volatile unsigned int *DWT_CONTROL  = (volatile unsigned int *)0xE0001000; //address of the register
    volatile unsigned int *DWT_LAR      = (volatile unsigned int *)0xE0001FB0; //address of the register
    volatile unsigned int *SCB_DEMCR    = (volatile unsigned int *)0xE000EDFC; //address of the register
    uint32_t x, y;
    uint32_t Cycles;
    *SCB_DEMCR |= 0x01000000;
    *DWT_LAR = 0xC5ACCE55; // enable access
    *DWT_CYCCNT = 0; // reset the counter
    *DWT_CONTROL |= 1 ; // enable the counter

    while (1){
        /* USER CODE END WHILE */

        /* USER CODE BEGIN 3 */
        //heart beat
        HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_0);

        //randomise data, if NOISE==1
        int iij=0;
        HAL_RNG_GenerateRandomNumber(&hrng,&rand);
        if (NOISE){
            while (reflPwr[iij] < calcThreshLwr){
                HAL_RNG_GenerateRandomNumber(&hrng,&rand);
                randomReflPwr[iij] = ((int32_t) reflPwr[iij])+(rand>>24);//was 26
                //output noise while debugging
                //sprintf(txbuf1,"%d \r\n",(rand>>26));
                //HAL_UART_Transmit(&huart3,(uint8_t *) txbuf1,strlen(txbuf1),100);
                iij++;
            }
        }else{
            while (reflPwr[iij] >= calcThresh){
                randomReflPwr[iij] = reflPwr[iij];
                iij++;
            }
        }

        //reset accumulators
        f32accum1=0.0f;
        f32accum2=0.0f;
        f64accum1=0.0f;
        f64accum2=0.0f;
        i32accum1=0.0f;
        i32accum2=0.0f;
        q31accum1=0;
        q31accum2=0;

        /*
         * All weighted average, multiply and conversion functions are adapted
         * from the CMSIS Library: Copyright (c) 2010-2021 Arm Limited or its affiliates. All rights reserved.
         * -----
         * The cycle counter was proposed by a ST community forum member (Tesla DeLorean,
         * https://community.st.com/t5/stm32-mcu-products/how-do-i-calculate-how-many-clock-cycles-are-needed-to-run-block/td-p/134579)
         * */
        /*
         * Copyright (c) 2010-2021 Arm Limited or its affiliates. All rights reserved.
         *
         * SPDX-License-Identifier: Apache-2.0
         *
         * Licensed under the Apache License, Version 2.0 (the License); you may
         * not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         * www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an AS IS BASIS, WITHOUT
         * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */

        arm_float_to_q31(q31f32tuneVolt,q31tuneVolt, BSIZE);
        arm_float_to_q31(q31f32tuneVolt_,q31tuneVolt_, BSIZE);

        //turn stop watch on for one NOP
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, 1);
        __asm__("NOP");
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,0);

        //small pause in between measurements
        pause10cyc();

        /*--------------------------
        * uint32_t ALTERNATIVE (optimised search for values bigger than threshold
        * ~30% faster than uint32 described in paper)
        ----------------------------*/
        int ii=0;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,1);
        x = *DWT_CYCCNT;
        //vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        // TIME MEAS STARTS HERE
        //vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        while (reflPwr[ii++] >= calcThresh){}

        while (reflPwr[ii] < calcThreshLwr){
            i32reflPwr = MAX_ADCVAL - reflPwr[ii];
            i32accum1 += i32reflPwr * i32tuneVolt[ii];
            i32accum2 += i32reflPwr;
            ii++;

        }


        i32result=(float)i32accum1/(float)i32accum2;

        //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        // TIME MEAS STOPS HERE
        //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        y = *DWT_CYCCNT;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,0);


        Cycles = (y - x);
        //print cycle counter for uint32_t
        sprintf(txbuf1,"cycui32: %d \r\n",Cycles);
        HAL_UART_Transmit(&huart3,(uint8_t *) txbuf1,strlen(txbuf1),100);

        pause10cyc();

        /*--------------------------
        * float32_t
        ----------------------------*/
        int i=0;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,1);
        x = *DWT_CYCCNT;
        //vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        // TIME MEAS STARTS HERE
        //vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

        while (reflPwr[i] >= calcThresh){
            i++;
        }
        while (reflPwr[i] < calcThreshLwr){
            f32reflPwr = (float) reflPwr[i] - MAXADCVALFLOAT;
            f32accum1 += f32reflPwr * f32tuneVolt[i];
            f32accum2 += f32reflPwr;
            i++;
        }
        f32result=f32accum1/f32accum2;

        //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        // TIME MEAS STOPS HERE
        //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        y = *DWT_CYCCNT;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,0);


        Cycles = (y - x);
        //print cycle counter for float32_t
        sprintf(txbuf1,"cycf32: %d \r\n",Cycles);
        HAL_UART_Transmit(&huart3,(uint8_t *) txbuf1,strlen(txbuf1),100);



//        /*--------------------------
//        * uint32_t (as described in the paper)
//        ----------------------------*/
        /*

        *DWT_CYCCNT = 0; // reset the counter
        *DWT_CONTROL |= 1 ; // enable the counter

        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,1);

        int ii=0;
        while (reflPwr[ii] >= calcThresh){
                    ii++;
        }

        while (reflPwr[ii] < calcThreshLwr){

            if (NOISE) {
                //introduce some degree of randomness into variable
                i32reflPwr = MAX_ADCVAL - randomReflPwr[ii];

            }else{
                if (RED_RESOLUTION){
                    //reduce ADC resolution and check if result is still within 0.8mV of actual result
                    //4 bit resolution loss seems to work, 5 does not
                    i32reflPwr = (MAX_ADCVAL - reflPwr[ii])>>4;
                }else{
                     x = *DWT_CYCCNT;
                    i32reflPwr = MAX_ADCVAL - reflPwr[ii];

                }
            }

            i32accum1 += i32reflPwr * i32tuneVolt[ii];
            i32accum2 += i32reflPwr;
            ii++;
        }


        i32result=(float)i32accum1/(float)i32accum2;
        y = *DWT_CYCCNT;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,0);


        Cycles = (y - x);
        sprintf(txbuf1,"cycui32: %d \r\n",Cycles);

        HAL_UART_Transmit(&huart3,(uint8_t *) txbuf1,strlen(txbuf1),100);
        pause10cyc(void);
*/

        /*--------------------------
        * q31_t
        ----------------------------*/
        float32_t fscreflPwr;
        q31accum1=0;
        q31accum2=0;
        *DWT_CYCCNT = 0; // reset the counter
        *DWT_CONTROL |= 1 ; // enable the counter
        x = *DWT_CYCCNT;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,1);

        int iii=0;
        while (reflPwr[iii] >= calcThresh){
            iii++;
        }
        while (reflPwr[iii] < calcThreshLwr){
            fscreflPwr=(((int32_t)reflPwr[iii]) - MAX_ADCVAL)/MAX_REFL_VAL;
            q31reflPwr = clip_q63_to_q31((q63_t) (fscreflPwr * MAX_Q31_TO_FLOAT_SCALE));
            q31accum1 += __SSAT(((q63_t) q31tuneVolt_[iii] * q31reflPwr) >> 32,31) << 1U;
            q31accum2 += q31reflPwr;
            //output variables for possible q31 overflow detection
//            sprintf(txbuf1,"%d \r\n",q31accum1);
//            HAL_UART_Transmit(&huart3,(uint8_t *) txbuf1,strlen(txbuf1),100);
//            sprintf(txbuf1,"a2: %d \r\n",q31accum2);
//            HAL_UART_Transmit(&huart3,(uint8_t *) txbuf1,strlen(txbuf1),100);
//            HAL_Delay(10);
            iii++;
        }

        q31faccum1 = (((float32_t) q31accum1) / maxQ31toFloatScale);
        q31faccum2 = (((float32_t) q31accum2) / maxQ31toFloatScale);

        q31result = (q31faccum1 / q31faccum2)*21.5f;
        //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        // TIME MEAS STOPS HERE
        //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        y = *DWT_CYCCNT;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8,0);
        Cycles = (y - x);
        //print cycle counter for q31_t
        sprintf(txbuf1,"cycq31: %d \r\n",Cycles);
        HAL_UART_Transmit(&huart3,(uint8_t *) txbuf1,strlen(txbuf1),100);
        //print all results
        sprintf(txbuf1,"%12.9f \r\n",f32result);
        HAL_UART_Transmit(&huart3,(uint8_t *) txbuf1,strlen(txbuf1),100);
        sprintf(txbuf2,"%12.9f \r\n",i32result);
        HAL_UART_Transmit(&huart3,(uint8_t *) txbuf2,strlen(txbuf2),100);
        sprintf(txbuf3,"%12.9f \r\n",q31result);
        HAL_UART_Transmit(&huart3,(uint8_t *) txbuf3,strlen(txbuf3),100);
        sprintf(txbuf4,"------ \r\n");
        HAL_UART_Transmit(&huart3,(uint8_t *) txbuf4,strlen(txbuf4),100);

        //wait 0.1s for next round of measurements
        HAL_Delay(100);
    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE0);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI48|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 275;
  RCC_OscInitStruct.PLL.PLLP = 1;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_1;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ETH Initialization Function
  * @param None
  * @retval None
  */
static void MX_ETH_Init(void)
{

  /* USER CODE BEGIN ETH_Init 0 */

  /* USER CODE END ETH_Init 0 */

   static uint8_t MACAddr[6];

  /* USER CODE BEGIN ETH_Init 1 */

  /* USER CODE END ETH_Init 1 */
  heth.Instance = ETH;
  MACAddr[0] = 0x00;
  MACAddr[1] = 0x80;
  MACAddr[2] = 0xE1;
  MACAddr[3] = 0x00;
  MACAddr[4] = 0x00;
  MACAddr[5] = 0x00;
  heth.Init.MACAddr = &MACAddr[0];
  heth.Init.MediaInterface = HAL_ETH_RMII_MODE;
  heth.Init.TxDesc = DMATxDscrTab;
  heth.Init.RxDesc = DMARxDscrTab;
  heth.Init.RxBuffLen = 1524;

  /* USER CODE BEGIN MACADDRESS */

  /* USER CODE END MACADDRESS */

  if (HAL_ETH_Init(&heth) != HAL_OK)
  {
    Error_Handler();
  }

  memset(&TxConfig, 0 , sizeof(ETH_TxPacketConfig));
  TxConfig.Attributes = ETH_TX_PACKETS_FEATURES_CSUM | ETH_TX_PACKETS_FEATURES_CRCPAD;
  TxConfig.ChecksumCtrl = ETH_CHECKSUM_IPHDR_PAYLOAD_INSERT_PHDR_CALC;
  TxConfig.CRCPadCtrl = ETH_CRC_PAD_INSERT;
  /* USER CODE BEGIN ETH_Init 2 */

  /* USER CODE END ETH_Init 2 */

}

/**
  * @brief RNG Initialization Function
  * @param None
  * @retval None
  */
static void MX_RNG_Init(void)
{

  /* USER CODE BEGIN RNG_Init 0 */

  /* USER CODE END RNG_Init 0 */

  /* USER CODE BEGIN RNG_Init 1 */

  /* USER CODE END RNG_Init 1 */
  hrng.Instance = RNG;
  hrng.Init.ClockErrorDetection = RNG_CED_ENABLE;
  if (HAL_RNG_Init(&hrng) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RNG_Init 2 */

  /* USER CODE END RNG_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart3, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart3, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief USB_OTG_HS Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_OTG_HS_USB_Init(void)
{

  /* USER CODE BEGIN USB_OTG_HS_Init 0 */

  /* USER CODE END USB_OTG_HS_Init 0 */

  /* USER CODE BEGIN USB_OTG_HS_Init 1 */

  /* USER CODE END USB_OTG_HS_Init 1 */
  /* USER CODE BEGIN USB_OTG_HS_Init 2 */

  /* USER CODE END USB_OTG_HS_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LED_GREEN_Pin|LED_RED_Pin|TIMIN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(USB_FS_PWR_EN_GPIO_Port, USB_FS_PWR_EN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_YELLOW_GPIO_Port, LED_YELLOW_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LED_GREEN_Pin LED_RED_Pin */
  GPIO_InitStruct.Pin = LED_GREEN_Pin|LED_RED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : USB_FS_PWR_EN_Pin */
  GPIO_InitStruct.Pin = USB_FS_PWR_EN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(USB_FS_PWR_EN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : USB_FS_OVCR_Pin */
  GPIO_InitStruct.Pin = USB_FS_OVCR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USB_FS_OVCR_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : USB_FS_VBUS_Pin */
  GPIO_InitStruct.Pin = USB_FS_VBUS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USB_FS_VBUS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : USB_FS_ID_Pin */
  GPIO_InitStruct.Pin = USB_FS_ID_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF10_OTG1_HS;
  HAL_GPIO_Init(USB_FS_ID_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : TIMIN_Pin */
  GPIO_InitStruct.Pin = TIMIN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(TIMIN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LED_YELLOW_Pin */
  GPIO_InitStruct.Pin = LED_YELLOW_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_YELLOW_GPIO_Port, &GPIO_InitStruct);

  /**/
  HAL_I2CEx_EnableFastModePlus(SYSCFG_PMCR_I2C_PB8_FMP);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/*
 * Copyright (c) 2010-2021 Arm Limited or its affiliates. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

float32_t arm_weighted_sum_f32(const float32_t *in, const float32_t *weigths, uint32_t blockSize)
{

return 0.0f;
}

/* ----------------------------------------------------------------------
 * Project:            CMSIS DSP Library
 * Title:                arm_mult_q31.c
 * Description:    Q31 vector multiplication
 *
 * $Date:                23 April 2021
 * $Revision:        V1.9.0
 *
 * Target Processor: Cortex-M and Cortex-A cores
 * -------------------------------------------------------------------- */
/*
 * Copyright (C) 2010-2021 ARM Limited or its affiliates. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* ----------------------------------------------------------------------
 * Project:            CMSIS DSP Library
 * Title:                arm_q31_to_float.c
 * Description:    Converts the elements of the Q31 vector to floating-point vector
 *
 * $Date:                23 April 2021
 * $Revision:        V1.9.0
 *
 * Target Processor: Cortex-M and Cortex-A cores
 * -------------------------------------------------------------------- */
/*
 * Copyright (C) 2010-2021 ARM Limited or its affiliates. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "dsp/support_functions.h"

/**
    @brief                 Converts the elements of the Q31 vector to floating-point vector.
    @param[in]         pSrc             points to the Q31 input vector
    @param[out]        pDst             points to the floating-point output vector
    @param[in]         blockSize    number of samples in each vector
    @return                none

    @par                     Details
                                     The equation used for the conversion process is:
    <pre>
            pDst[n] = (float32_t) pSrc[n] / 2147483648;     0 <= n < blockSize.
    </pre>
 */

void arm_q31_to_float(
    const q31_t * pSrc,
    float32_t * pDst,
    uint32_t blockSize)
{
    const q31_t *pIn = pSrc;                                                         /* Src pointer */
    uint32_t blkCnt;                                                             /* loop counter */


    /* Initialize blkCnt with number of samples */
    blkCnt = blockSize;
 /* #if defined (ARM_MATH_LOOPUNROLL) */

    while (blkCnt > 0U)
    {
        /* C = (float32_t) A / 2147483648 */

        /* Convert from q31 to float and store result in destination buffer */
        *pDst++ = ((float32_t) *pIn++ / 2147483648.0f);

        /* Decrement loop counter */
        blkCnt--;
    }

}

/*
 * Copyright (C) 2010-2021 ARM Limited or its affiliates. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

void arm_float_to_q31(const float32_t * pSrc, q31_t * pDst, uint32_t blockSize){
    uint32_t blkCnt;                                                             /* Loop counter */
    const float32_t *pIn = pSrc;                                                 /* Source pointer */

    /* Initialize blkCnt with number of samples */
    blkCnt = blockSize;
    /* #if defined (ARM_MATH_LOOPUNROLL) */

    while (blkCnt > 0U)
    {
        /* C = A * 2147483648 */

        /* convert from float to Q31 and store result in destination buffer */

        /* C = A * 2147483648 */
        /* Convert from float to Q31 and then store the results in the destination buffer */
        *pDst++ = clip_q63_to_q31((q63_t) (*pIn++ * 2147483648.0f));

        /* Decrement loop counter */
        blkCnt--;
    }

}


void pause10cyc(void){
    for (volatile uint16_t i=0; i!=BR_BTW_MEAS; i++){__asm__("NOP");}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */
    __disable_irq();
    while (1)
    {
    }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
    /* User can add his own implementation to report the file name and line number,
         ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
